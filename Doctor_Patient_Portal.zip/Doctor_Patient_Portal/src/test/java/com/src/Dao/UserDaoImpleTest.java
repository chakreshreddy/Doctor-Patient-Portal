package com.src.Dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.src.model.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class UserDaoImpleTest {

    private UserDao userDao;
    private DaoService daoService;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        userDao = new UserDaoImple();
        daoService = Mockito.mock(DaoService.class);
        preparedStatement = Mockito.mock(PreparedStatement.class);
        resultSet = Mockito.mock(ResultSet.class);

        try {
			Mockito.when(daoService.getMyPreparedStatement(Mockito.anyString())).thenReturn(preparedStatement);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @Disabled
    @Test
    void testUserRegister() throws SQLException {
        User user = new User();
        user.setFullName("Chakresh Reddy");
        user.setEmail("chakreshreddyo3@gmail.com");
        user.setPassword("chakri");

        Mockito.when(preparedStatement.executeUpdate()).thenReturn(1);

        assertTrue(userDao.userRegister(user));
    }
    @Disabled
    @Test
    void testLoginUser() throws SQLException {
        String email = "chakri@gmail.com";
        String password = "password";

        Mockito.when(preparedStatement.executeQuery()).thenReturn(resultSet);
        Mockito.when(resultSet.next()).thenReturn(true);
        Mockito.when(resultSet.getInt("id")).thenReturn(1);
        Mockito.when(resultSet.getString("fullName")).thenReturn("cherry");
        Mockito.when(resultSet.getString("email")).thenReturn("cherry@gmail.com");
        Mockito.when(resultSet.getString("password")).thenReturn("cherry");

        User user = userDao.loginUser(email, password);

        assertNotNull(user);
        assertEquals(1, user.getId());
        assertEquals("chakri", user.getFullName());
        assertEquals(email, user.getEmail());
        assertEquals(password, user.getPassword());
    }
    
    @Test
    void testCheckOldPassword() throws SQLException {
        int userId = 1;
        String oldPassword = "chakri";

        Mockito.when(preparedStatement.executeQuery()).thenReturn(resultSet);
        Mockito.when(resultSet.next()).thenReturn(true);

        assertTrue(userDao.checkOldPassword(userId, oldPassword));
    }
    @Disabled
    @Test
    void testChangePassword() throws SQLException {
        int userId = 2002;
        String newPassword = "12345";

        Mockito.when(preparedStatement.executeUpdate()).thenReturn(1);

        assertTrue(userDao.changePassword(userId, newPassword));
    }
}
