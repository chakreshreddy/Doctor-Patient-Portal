/**
 * 
 */// validation.js

function validateForm() {
    var fullName = document.getElementById("fullName").value;
    var dateOfBirth = document.getElementById("dateOfBirth").value;
    var qualification = document.getElementById("qualification").value;
    var specialist = document.getElementById("specialist").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var password = document.getElementById("password").value;

    // Validation for Full Name
    if (fullName.trim() === "") {
        alert("Please enter full name.");
        return false;
    }

    // Validation for Date of Birth (you can add further validation as needed)
    if (dateOfBirth.trim() === "") {
        alert("Please enter date of birth.");
        return false;
    }

    // Validation for Qualification
    if (qualification.trim() === "") {
        alert("Please enter qualification.");
        return false;
    }

    // Validation for Specialist
    if (specialist === "---Select---") {
        alert("Please select a specialist.");
        return false;
    }

    // Validation for Email
    if (email.trim() === "") {
        alert("Please enter email address.");
        return false;
    }

    // Validation for Phone
    if (phone.trim() === "") {
        alert("Please enter phone number.");
        return false;
    }

    // Validation for Password
    if (password.trim() === "") {
        alert("Please enter password.");
        return false;
    }

    return true;
}
