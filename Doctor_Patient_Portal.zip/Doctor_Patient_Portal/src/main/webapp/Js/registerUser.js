/**
 * 
 */
function validateFullName() {
    var fullName = document.forms["registrationForm"]["fullName"].value;
    var letters = /^[A-Za-z\s]+$/;
    if (!fullName.match(letters)) {
        alert("Full Name should contain only alphabets and spaces.");
        return false;
    }
    return true;
}

function validateEmail() {
    var email = document.forms["registrationForm"]["email"].value;
    var emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
    if (!email.match(emailPattern)) {
        alert("Please enter a valid email address.");
        return false;
    }
    return true;
}

function validatePassword() {
    var password = document.forms["registrationForm"]["password"].value;
    var passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
    if (!password.match(passwordPattern)) {
        alert("Password should contain at least one alphabet, one number, one special character, and be at least 8 characters long.");
        return false;
    }
    return true;
}

function validateForm() {
    if (!validateFullName() || !validateEmail() || !validatePassword()) {
        return false;
    }
    return true;
}
