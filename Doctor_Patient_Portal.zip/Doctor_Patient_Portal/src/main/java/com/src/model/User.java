/**
 * Author: @chakreshReddy
 * Purpose: This is the User model class that contains all the required information 
 * from the user.
 * Date: last modified on 28-09-2023.
 */

package com.src.model;

import com.src.annotate.Constraint;
import com.src.annotate.Table;
import com.src.annotate.TableAnnotation;
@TableAnnotation
public class User {
	@Constraint(constraint = "primary key")
	private int id;
	private String fullName;
	private String email;
	private String password;
	@Override
	public String toString() {
		return "User [id=" + id + ", fullName=" + fullName + ", email=" + email + ", password=" + password + "]";
	}
	public User() {
		if(this.getClass().isAnnotationPresent(TableAnnotation.class)) {
			Table.createTable(this.getClass().getCanonicalName());
		}
	}
	public User(int id, String fullName, String email, String password) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.email = email;
		this.password = password;
	}
	
	public User(String fullName, String email, String password) {
		super();
		this.fullName = fullName;
		this.email = email;
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
