/**
 * Author: @chakreshReddy
 * Purpose: This is the Specialist  model class that describes all 
 * information about specializations present in our hospital.
 * Date: last modified on 28-09-2023.
 */
package com.src.model;

import com.src.annotate.Constraint;
import com.src.annotate.Table;
import com.src.annotate.TableAnnotation;
@TableAnnotation
public class Specialist {
	@Constraint(constraint = "primary key")
	private int id;
	private String specialistName;
	@Override
	public String toString() {
		return "Specialist [id=" + id + ", specialistName=" + specialistName + "]";
	}
	public Specialist() {
		if(this.getClass().isAnnotationPresent(TableAnnotation.class)) {
			Table.createTable(this.getClass().getCanonicalName());
		}
	}
	public Specialist(int id, String specialistName) {
		super();
		this.id = id;
		this.specialistName = specialistName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSpecialistName() {
		return specialistName;
	}
	public void setSpecialistName(String specialistName) {
		this.specialistName = specialistName;
	}

}
