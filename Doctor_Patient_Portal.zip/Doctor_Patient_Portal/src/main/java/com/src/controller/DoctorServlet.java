package com.src.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.src.Dao.DoctorDao;
import com.src.Dao.DoctorDaoImple;
import com.src.model.Doctor;

/**
 * Servlet implementation class DoctorServlet
 */
@WebServlet("/doctor")
public class DoctorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		session.removeAttribute("doctorObj");
		session.setAttribute("successMsg", "Doctor Logout Successfully.");
		resp.sendRedirect("doctor_login.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 String mode = req.getParameter("mode");
		 if (mode.equals("login")) {
			 String email = req.getParameter("email");
				String password = req.getParameter("password");

				//create session
				HttpSession session = req.getSession();

				//create DB connection
				DoctorDao docDAO = new DoctorDaoImple();
				
				//call loginDoctor() method for doctor login which method declared in DoctorDAO 
				Doctor doctor = docDAO.loginDoctor(email, password);

				if (doctor != null) {
					//means doctor is valid or exist
					//then store particular logged in doctor object in session
					session.setAttribute("doctorObj", doctor);
					//and redirect the particular doctor index page which is reside doctor folder
					resp.sendRedirect("doctor/index.jsp");//doctor index means dashboard of doctors
				} else {
					session.setAttribute("errorMsg", "Invalid email or password");
					resp.sendRedirect("doctor_login.jsp");
				}
				
			 
		 }
		 else if (mode.equals("changePassword")) {
	            int doctorId = Integer.parseInt(req.getParameter("doctorId"));
	            String newPassword = req.getParameter("newPassword");
	            String oldPassword = req.getParameter("oldPassword");

	            DoctorDao doctorDAO = new DoctorDaoImple();
	            HttpSession session = req.getSession();

	            if (doctorDAO.checkOldPassword(doctorId, oldPassword)) {
	                if (doctorDAO.changePassword(doctorId, newPassword)) {
	                    session.setAttribute("successMsg", "Password changed successfully.");
	                    resp.sendRedirect("doctor/edit_profile.jsp");
	                } else {
	                    session.setAttribute("errorMsg", "Something went wrong on the server!");
	                    resp.sendRedirect("doctor/edit_profile.jsp");
	                }
	            } else {
	                session.setAttribute("errorMsg", "Old Password does not match");
	                resp.sendRedirect("doctor/edit_profile.jsp");
	            }
	        }
		 else if (mode.equals("edit")) {
			 try {

					// get all data which is coming from doctor.jsp doctor details
					String fullName = req.getParameter("fullName");
					String dateOfBirth = req.getParameter("dateOfBirth");
					String qualification = req.getParameter("qualification");
					String specialist = req.getParameter("specialist");
					String email = req.getParameter("email");
					String phone = req.getParameter("phone");
					//String password = req.getParameter("password");

					
					int id = Integer.parseInt(req.getParameter("doctorId"));

					Doctor doctor = new Doctor(id, fullName, dateOfBirth, qualification, specialist, email, phone, "");

					DoctorDao docDAO = new DoctorDaoImple();

					boolean f = docDAO.editDoctorProfile(doctor);

					HttpSession session = req.getSession();

					if (f == true) {
						Doctor updateDoctorObj = docDAO.getDoctorById(id);
						session.setAttribute("successMsgForD", "Doctor update Successfully");
						session.setAttribute("doctorObj", updateDoctorObj); // over ride or update old session value to new updated doctor value.
						resp.sendRedirect("doctor/edit_profile.jsp");

					} else {
						session.setAttribute("errorMsgForD", "Something went wrong on server!");
						resp.sendRedirect("doctor/edit_profile.jsp");
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
		 }
		
	}

}
