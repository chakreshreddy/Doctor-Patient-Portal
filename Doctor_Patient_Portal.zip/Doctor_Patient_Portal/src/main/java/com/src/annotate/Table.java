/**
 * Author: @chakreshReddy
 * Purpose: This Java program defines a utility class, Table, 
 * for dynamically generating SQL CREATE TABLE statements based on 
 * Java class fields and their annotations. It establishes a database connection,
 *  inspects class fields using reflection, and
 *  constructs SQL statements to create tables with appropriate columns and constraints.
 * Date: last modified on 28-09-2023.
 */
package com.src.annotate;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Table {
	static Statement st = null;
	static Connection c = null;
	public static Statement getConn() {
		try {
		
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=chakri;integratedSecurity=true ;encrypt=true;trustServerCertificate=true");
			st = c.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return st;

	}

	public static void closeConn() {
		try {
			c.close();
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static boolean createTable(String name) {
	    Class<?> c = null;
	    try {
	        c = Class.forName(name);
	    } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    Field[] f = c.getDeclaredFields();
	    StringBuilder query = new StringBuilder("CREATE TABLE " + c.getSimpleName() + " (");

	    for (Field tf : f) {
	        String name1 = tf.getType().getSimpleName();
	        String actname = null;

	        if (tf.getName().equals("id")) {
	            // If the field is "id," set it as an identity column
	            query.append("id INT IDENTITY(1,1) PRIMARY KEY,");
	            continue; // Skip the rest of the loop for "id" field
	        } else if (name1.equals("int"))
	            actname = "INT";
	        else if (name1.equals("boolean"))
	            actname = "BIT";
	        else if (name1.equals("byte"))
	            actname = "TINYINT";
	        else if (name1.equals("short"))
	            actname = "SMALLINT";
	        else if (name1.equals("long"))
	            actname = "BIGINT";
	        else if (name1.equals("float"))
	            actname = "REAL";
	        else if (name1.equals("double"))
	            actname = "FLOAT";
	        else if (name1.equals("char"))
	            actname = "CHAR";
	        else if (name1.equals("String"))
	            actname = "VARCHAR(30)";
	        else
	            continue;

	        query.append(tf.getName()).append(" ").append(actname);

	        if (tf.isAnnotationPresent(Constraint.class)) {
	            query.append(" ").append(tf.getAnnotation(Constraint.class).constraint());
	        }

	        query.append(",");
	    }

	    query.deleteCharAt(query.length() - 1);
	    query.append(");");
	    getConn();
	    System.out.println(query);
	    boolean check = false;

	    try {
	        check = st.execute(query.toString());
	    } catch (SQLException e) {
//	        e.printStackTrace();
	    }

	    closeConn();

	    return check;
	}
}
