/**
 * Author: @chakreshReddy
 * Purpose: This Java code defines an annotation named Constraint with a constraint 
element that allows you to specify constraints on fields. 
The annotation is retained at runtime and is intended for annotating fields in classes.
 * Date: last modified on 28-09-2023.
 */
package com.src.annotate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Constraint {
	String constraint() default "none";
}
