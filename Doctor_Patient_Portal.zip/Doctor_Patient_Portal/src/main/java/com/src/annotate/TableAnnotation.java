/**
 * Author: @chakreshReddy
 * Purpose: The Java program defines a custom annotation 
 * TableAnnotation that can be applied to Java class definitions
 * Date: last modified on 28-09-2023.
 */
package com.src.annotate;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface TableAnnotation {

}
