/**
 * Author: @chakreshReddy
 * Purpose: This is the DoctorService Interface which contain all the methods
 *  present in appointment which also helps for the data abstraction by acting as intermeditory 
 *  for controller and model class.
 * Date: last modified on 28-09-2023.
 */

package com.src.service;

import java.util.List;

import com.src.model.Doctor;

public interface DoctorService {
	public boolean registerDoctor(Doctor doctor);
	public List<Doctor> getAllDoctor();
	public Doctor getDoctorById(int id);
	public boolean updateDoctor(Doctor doctor);
	public boolean deleteDoctorById(int id);
	public Doctor loginDoctor(String email, String password);
	public int countTotalDoctor();
	public int countTotalAppointment();
	public int countTotalAppointmentByDoctorId(int doctorId);
	public int countTotalUser();
	public int countTotalSpecialist();
	public boolean checkOldPassword(int doctorId, String oldPassword);
	public boolean changePassword(int doctorId, String newPassword);
	public boolean editDoctorProfile(Doctor doctor);

}
