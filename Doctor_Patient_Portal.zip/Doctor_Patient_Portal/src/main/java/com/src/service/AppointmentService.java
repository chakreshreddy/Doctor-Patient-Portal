/**
 * Author: @chakreshReddy
 * Purpose: This is the AppintmentService Interface which contain all the methods
 *  present in appointment which also helps for the data abstraction by acting as intermeditory 
 *  for controller and model class.
 * Date: last modified on 28-09-2023.
 */

package com.src.service;

import java.util.List;

import com.src.model.Appointment;

public interface AppointmentService {
	public boolean addAppointment(Appointment appointment);
	public List<Appointment> getAllAppointmentByLoginUser(int userId);
	public List<Appointment> getAllAppointmentByLoginDoctor(int doctorId);
	public Appointment getAppointmentById(int id);
	public boolean updateDrAppointmentCommentStatus(int apptId, int docId, String comment);
	public List<Appointment> getAllAppointment();

}
