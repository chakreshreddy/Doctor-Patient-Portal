/**
 * Author: @chakreshReddy
 * Purpose: This is the UserService Interface which contain all the methods
 *  present in appointment which also helps for the data abstraction by acting as intermeditory 
 *  for controller and model class.
 * Date: last modified on 28-09-2023.
 */
package com.src.service;

import java.sql.SQLException;

import com.src.model.User;

public interface UserService {
	public boolean userRegister(User user) throws SQLException;
	public User loginUser(String email, String password);
	public boolean checkOldPassword(int userId, String oldPassword);
	public boolean changePassword(int userId, String newPassword);

}
