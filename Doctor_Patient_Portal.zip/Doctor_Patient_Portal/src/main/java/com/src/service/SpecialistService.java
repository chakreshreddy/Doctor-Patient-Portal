/**
 * Author: @chakreshReddy
 * Purpose: This is the SpecialistService Interface which contain all the methods
 *  present in appointment which also helps for the data abstraction by acting as intermeditory 
 *  for controller and model class.
 * Date: last modified on 28-09-2023.
 */

package com.src.service;

import java.util.List;

import com.src.model.Specialist;

public interface SpecialistService {
	public boolean addSpecialist(String sp);
	public List<Specialist> getAllSpecialist();

}
