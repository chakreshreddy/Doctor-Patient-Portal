/**
 * Author: @chakreshReddy
 * Purpose: This is the selenium test case class in which the automation testing done
 * to admin page. In this class we are also testing the browser compatibility of our 
 * application in different browsers.
 * Date: last modified on 28-09-2023.
 */

package com.sec.seleniumtest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MainE {
    static String browser = "chrome";
    static WebDriver driver;

    public static void main(String[] args) {
        if (browser.equals("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
            driver.get("http://localhost:8080/Doctor_Patient_Portal/");

            try {
                
            	WebDriverWait wait = new WebDriverWait(driver, java.time.Duration.ofSeconds(10));
                WebElement liElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li.nav-item")));
                WebElement anchorElement = liElement.findElement(By.cssSelector("a.nav-link.active"));
                anchorElement.click();
                WebElement emailInput = driver.findElement(By.name("email"));
                emailInput.sendKeys("admin@gmail.com");
                WebElement passwordInput = driver.findElement(By.name("password"));
                passwordInput.sendKeys("admin");
                WebElement submitButton = driver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
                submitButton.click();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                
            }
        }
        else if(browser.equals("chrome")) {
        	WebDriverManager.chromedriver().setup();
        	driver= new ChromeDriver();
        	 driver.get("http://localhost:8080/Doctor_Patient_Portal/");

             try {
                 
             	WebDriverWait wait = new WebDriverWait(driver, java.time.Duration.ofSeconds(10));
                 WebElement liElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li.nav-item")));
                 WebElement anchorElement = liElement.findElement(By.cssSelector("a.nav-link.active"));
                 anchorElement.click();
                 WebElement emailInput = driver.findElement(By.name("email"));
                 emailInput.sendKeys("admin@gmail.com");
                 WebElement passwordInput = driver.findElement(By.name("password"));
                 passwordInput.sendKeys("admin");
                 WebElement submitButton = driver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
                 submitButton.click();
             } catch (Exception e) {
                 e.printStackTrace();
             } finally {
                 
             }
        }
        else if(browser.equals("firefox")) {
        	WebDriverManager.firefoxdriver().setup();
        	driver = new FirefoxDriver();
        	 driver.get("http://localhost:8080/Doctor_Patient_Portal/");

             try {
                 
             	WebDriverWait wait = new WebDriverWait(driver, java.time.Duration.ofSeconds(10));
                 WebElement liElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("li.nav-item")));
                 WebElement anchorElement = liElement.findElement(By.cssSelector("a.nav-link.active"));
                 anchorElement.click();
                 WebElement emailInput = driver.findElement(By.name("email"));
                 emailInput.sendKeys("admin@gmail.com");
                 WebElement passwordInput = driver.findElement(By.name("password"));
                 passwordInput.sendKeys("admin");
                 WebElement submitButton = driver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
                 submitButton.click();
             } catch (Exception e) {
                 e.printStackTrace();
             } finally {
                 
             }
        }
        else {
        	System.out.println("Error in finding your browser chech your version properly");
        }
    }
}
