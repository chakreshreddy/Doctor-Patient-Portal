package com.src.ctrl;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.src.Dao.DoctorDao;
import com.src.Dao.DoctorDaoImple;
import com.src.Dao.SpecialistDao;
import com.src.Dao.SpecialistDaoImple;
import com.src.model.Doctor;
import com.src.model.User;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/adminservlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    String mode = req.getParameter("mode");
	    String mode1 = req.getParameter("mode1");

	    if (mode.equals("login")) {
	        try {
	            // create one static Admin for this project
	            String email = req.getParameter("email");
	            String password = req.getParameter("password");

	            HttpSession session = req.getSession();

	            if ("admin@gmail.com".equals(email) && "admin".equals(password)) {
	                session.setAttribute("adminObj", new User());
	                resp.sendRedirect("admin/index.jsp");
	            } else {
	                session.setAttribute("errorMsg", "Invalid Username or Password.");
	                resp.sendRedirect("admin_login.jsp");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    } else if (mode.equals("adminLogout")) {
	        HttpSession session = req.getSession();
	        session.removeAttribute("adminObj");
	        // show message after logout
	        session.setAttribute("successMsg", "Admin Logout Successfully");
	        resp.sendRedirect("admin_login.jsp");
	    } 
	    else if (mode.equals("addDoctor")) {
	    	try {

				// get all data which is coming from doctor.jsp doctor details
				String fullName = req.getParameter("fullName");
				String dateOfBirth = req.getParameter("dateOfBirth");
				String qualification = req.getParameter("qualification");
				String specialist = req.getParameter("specialist");
				String email = req.getParameter("email");
				String phone = req.getParameter("phone");
				String password = req.getParameter("password");
				Doctor doctor = new Doctor(fullName, dateOfBirth, qualification, specialist, email, phone, password);
				
				DoctorDao docDAO = new DoctorDaoImple();

				boolean f = docDAO.registerDoctor(doctor);

				HttpSession session = req.getSession();

				if (f == true) {
					session.setAttribute("successMsg", "Doctor added Successfully");
					resp.sendRedirect("admin/doctor.jsp");

				} else {
					session.setAttribute("errorMsg", "Something went wrong on server!");
					resp.sendRedirect("admin/doctor.jsp");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
	    } 
	    else if (mode.equals("deleteDoctor")) {
	    	int id = Integer.parseInt(req.getParameter("id"));
			System.out.println("Id is "+id);
			DoctorDao docDAO = new DoctorDaoImple();
			HttpSession session = req.getSession();

			boolean f = docDAO.deleteDoctorById(id);

			if (f == true) {
				session.setAttribute("successMsg", "Doctor Deleted Successfully.");
				resp.sendRedirect("admin/view_doctor.jsp");
			} else {
				session.setAttribute("errorMsg", "Something went wrong on server!");
				resp.sendRedirect("admin/view_doctor.jsp");
			}
	    	

				
	    }
	    else if (mode1.equals("addSpecialist")) {
	    	String specialistName = req.getParameter("specialistName");
			
			SpecialistDao specialistDAO = new SpecialistDaoImple();
			boolean f = specialistDAO.addSpecialist(specialistName);
			
			HttpSession session = req.getSession();
			
			if (f==true) {
				session.setAttribute("successMsg", "Specialist added Successfully.");
				resp.sendRedirect("admin/index.jsp");
				
			} else {
				session.setAttribute("errorMsg", "Something went wrong on server");
				resp.sendRedirect("admin/index.jsp");
			}
	    }
	    
	    else {
	        System.out.println("Mode not found");
	    }
	    
	    
	}
}