package com.src.service;

import java.util.List;

import com.src.model.Specialist;

public interface SpecialistService {
	public boolean addSpecialist(String sp);
	public List<Specialist> getAllSpecialist();

}
