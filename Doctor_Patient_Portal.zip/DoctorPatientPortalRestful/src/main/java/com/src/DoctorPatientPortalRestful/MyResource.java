
package com.src.DoctorPatientPortalRestful;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.src.Dao.DoctorDaoImple;
import com.src.model.Doctor;
import com.src.service.DoctorService;
import com.src.service.DoctorServiceImple;

/** Example resource class hosted at the URI path "/myresource"
 */
@Path("/myresource")
public class MyResource {
	DoctorService ddi = new DoctorServiceImple();
    
    /** Method processing HTTP GET requests, producing "text/plain" MIME media
     * type.
     * @return String that will be send back as a response of type "text/plain".
     */
    @GET 
    @Produces("text/plain")
    public String getIt() {
        return "Hi there!";
    }
    @GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/alldoc")
    public List<Doctor> getAllDoctor(){
    	return ddi.getAllDoctor();
    }
    @PUT
	@Path("/upddtr/{doctor}")
	@Consumes(MediaType.APPLICATION_JSON)
    public boolean updateDoctor(Doctor d,@PathParam("doctor") int doctor) {
    	d.setId(doctor);
    	if (ddi.updateDoctor(d)) {
    		return true ;
    	}
    	else {
    		return false;
    	}
    	}
    @DELETE
    @Path("/{id}")
    public Response deleteDoctor(@PathParam("id") int id) {
        boolean deleted = ddi.deleteDoctorById(id);

        if (deleted) {
            return Response.noContent().build(); 
        } else {
            return Response.notModified().build(); 
        }
    }
    private final DoctorDaoImple doctorDaoImple = new DoctorDaoImple(); 

    @GET
    @Path("/doctors/count")
    public Response countTotalDoctors() {
        int totalDoctors = doctorDaoImple.countTotalDoctor();
        return Response.ok(totalDoctors, MediaType.APPLICATION_JSON).build();
    }

    @GET
    @Path("/appointments/count")
    public Response countTotalAppointments() {
        int totalAppointments = doctorDaoImple.countTotalAppointment();
        return Response.ok(totalAppointments, MediaType.APPLICATION_JSON).build();
    }

}
